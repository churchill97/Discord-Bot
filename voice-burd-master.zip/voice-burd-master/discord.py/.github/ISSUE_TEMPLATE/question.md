---
name: Question about the library
about: Please ask for help in Discord instead - https://discord.gg/r3sSKJJ
---

Generally speaking support questions are better answered in our Discord server. The response rate is faster and many people are willing to help. If you **really** feel like the question belongs here then feel free to delete this text and continue on. **Please do not open issues about asking how to implement a feature in your bot, these will be instantly closed.**

Our support servers can be found here:

Official server: https://discord.gg/r3sSKJJ
Discord API: https://discord.gg/discord-api
